function map1(){
  if(game.gametime==100){
    var a1=new enmy_f1();
    a1.init(4.5);
    game.Enmy.push(a1);
  }
  if(game.gametime==110){
    var a1=new enmy_f1();
     var a2=new enmy_f1();
    a1.init(3);
     a2.init(6);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
  }
  if(game.gametime==160){
    var g1=new enmy_f7();
    g1.init(3);
    game.Enmy.push(g1);
  }
  if(game.gametime==180){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(1);
    b2.init(4);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
   if(game.gametime==300){
    var g1=new enmy_f7();
    g1.init(5);
    game.Enmy.push(g1);
  }
  if(game.gametime==320){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(3);
    b2.init(6);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
 if(game.gametime==440){
    var g1=new enmy_f7();
    g1.init(2);
    game.Enmy.push(g1);
  }
  if(game.gametime==460){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(0);
    b2.init(3);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
   if(game.gametime==500){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(2.5);
    a2.init(5.5);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
  }
  if(game.gametime==510){
    var a1=new enmy_f1();
     var a2=new enmy_f1();
    a1.init(1);
    a2.init(4);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
  }
  if(game.gametime==570){
    var c1=new enmy_f3();
    var c2=new enmy_f3();
    c1.init(2,7);
    c2.init(5,3);
    game.Enmy.push(c1);
    game.Enmy.push(c2);
  }
   if(game.gametime==620){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
     var b3=new enmy_f2();
    b1.init(1);
    b2.init(4);
    b3.init(7);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
    game.Enmy.push(b3);
  }
  if(game.gametime==670){
     var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(1,1);
     b2.init(6,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
  }
   if(game.gametime==720){
     var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(1,1);
     b2.init(6,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
  }
   if(game.gametime==770){
     var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(1,1);
     b2.init(6,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
  }
  if(game.gametime==830){
    var a1=new enmy_f1();
     var a2=new enmy_f1();
    a1.init(3);
     a2.init(6);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    var a3=new enmy_f1();
     var a4=new enmy_f1();
    a1.init(1);
     a2.init(5);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
  if(game.gametime==880){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(2.5);
    a2.init(5.5);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
  }
  if(game.gametime==930){
     var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(0);
    a2.init(4);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
  }
  if(game.gametime==980){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    var a4=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    a4.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
  if(game.gametime==1030){
    var c1=new enmy_f3();
    c1.init(1,3);
    game.Enmy.push(c1);
  }
   if(game.gametime==1100){
    var g1=new enmy_f7();
    g1.init(3);
    game.Enmy.push(g1);
  }
  if(game.gametime==1130){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(1);
    b2.init(4);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
  if(game.gametime==1200){
    var g1=new enmy_f7();
    g1.init(5);
    game.Enmy.push(g1);
  }
  if(game.gametime==1230){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(6);
    b2.init(4);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
  if(game.gametime==1300){
    var c1=new enmy_f3();
    c1.init(5,7);
    game.Enmy.push(c1);
  }
  if(game.gametime==1370){
     var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(0,1);
     b2.init(5,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
  }
   if(game.gametime==1420){
     var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(0,1);
     b2.init(5,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
  }
   if(game.gametime==1470){
     var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(0,1);
     b2.init(5,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
  }
  if(game.gametime==1520){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
  }
  if(game.gametime==1570){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    a1.init(1);
    a2.init(3);
    a3.init(6);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
  }
  if(game.gametime==1620){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
  }
  if(game.gametime==1700){
    var c1=new enmy_f3();
    c1.init(4,7);
    game.Enmy.push(c1);
  }
  if(game.gametime==1770){
    var c1=new enmy_f3();
    c1.init(4,3);
    game.Enmy.push(c1);
  }
  if(game.gametime==1830){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    var a1=new enmy_f1();
    a1.init(3);
    b1.init(1);
    b2.init(5);
    game.Enmy.push(a1);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
  if(game.gametime==1900){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    var a1=new enmy_f1();
    a1.init(3);
    b1.init(1);
    b2.init(5);
    game.Enmy.push(a1);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  } 
  if(game.gametime==1950){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    var a1=new enmy_f1();
    a1.init(3);
    b1.init(1);
    b2.init(5);
    game.Enmy.push(a1);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  } 
  if(game.gametime==2000){
    var g1=new enmy_f7();
    var g2=new enmy_f7();
    var g3=new enmy_f7();
    g1.init(1);
    g2.init(3);
    g3.init(5);
    game.Enmy.push(g1);
    game.Enmy.push(g2);
    game.Enmy.push(g3);
  }
  if(game.gametime==2070){
    var g1=new enmy_f7();
    var g2=new enmy_f7();
    var g3=new enmy_f7();
    g1.init(0);
    g2.init(2);
    g3.init(4);
    game.Enmy.push(g1);
    game.Enmy.push(g2);
    game.Enmy.push(g3);
  }
   if(game.gametime==2140){
    var g1=new enmy_f7();
    var g2=new enmy_f7();
    var g3=new enmy_f7();
    g1.init(1);
    g2.init(3);
    g3.init(5);
    game.Enmy.push(g1);
    game.Enmy.push(g2);
    game.Enmy.push(g3);
  }
  if(game.gametime==2300){
    var boss=new boss1();
    boss.init(3.5);
    game.Enmy.push(boss);
  }
}
function map2(){
if(game.gametime==100){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    var a4=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    a4.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
  if(game.gametime==140){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    var a4=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    a4.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
  if(game.gametime==180){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    var a4=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    a4.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
  if(game.gametime==220){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    var a4=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    a4.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
  if(game.gametime==280){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    var a3=new enmy_f1();
    var a4=new enmy_f1();
    a1.init(0);
    a2.init(2);
    a3.init(5);
    a4.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    game.Enmy.push(a3);
    game.Enmy.push(a4);
  }
   if(game.gametime==340){
    var g1=new enmy_f7();
    g1.init(2);
    game.Enmy.push(g1);
  }
  if(game.gametime==360){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(0);
    b2.init(3);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
   if(game.gametime==400){
    var g1=new enmy_f7();
    g1.init(4);
    game.Enmy.push(g1);
  }
  if(game.gametime==420){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(2);
    b2.init(5);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
  }
  if(game.gametime==470){
    var c1=new enmy_f3();
    var c2=new enmy_f3();
    c1.init(1,3);
    c1.init(4,3);
    game.Enmy.push(c1);
    game.Enmy.push(c2);
  }
  if(game.gametime==520){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    d1.init(0);
    d2.init(7);
   game.Enmy.push(d1);
  game.Enmy.push(d2);
  }
if(game.gametime==550){
     var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(2);
     d2.init(5);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==580){
    var g1=new enmy_f7();
    g1.init(3.5);
    game.Enmy.push(g1);
}
if(game.gametime==610){
 var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(2);
     d2.init(5);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==640){
    var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(0);
     d2.init(7);
     game.Enmy.push(d1);
     game.Enmy.push(d2)
}
if(game.gametime==680){
    var c1=new enmy_f3();
    var c2=new enmy_f3();
    var c3=new enmy_f3();
    c1.init(3.5,5);
    c2.init(1,3);
    c3.init(6,3);
    game.Enmy.push(c1);
    game.Enmy.push(c2);
    game.Enmy.push(c3);
}
if(game.gametime==730){
    var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(2);
     d2.init(5);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==760){
    var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(0,1);
     b2.init(7,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
}
if(game.gametime==800){
   var b1=new enmy_f2();
     var b2=new enmy_f2();
     b1.init(2,1);
     b2.init(5,1);
     game.Enmy.push(b1);
     game.Enmy.push(b2);
}
if(game.gametime==830){
    var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(0);
     d2.init(7);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==870){
    var g1=new enmy_f7();
    g1.init(3.5);
    game.Enmy.push(g1);
}
if(game.gametime==900){
    var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(2);
     d2.init(5);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==950){
    var g1=new enmy_f7();
    var a1=new enmy_f1();
    a1.init(1);
    g1.init(3.5);
    game.Enmy.push(g1);
    game.Enmy.push(a1);
}
if(game.gametime==980){
    var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(2);
     d2.init(5);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==1030){
    var g1=new enmy_f7();
    var a1=new enmy_f1();
    a1.init(1);
    g1.init(5);
    game.Enmy.push(g1);
    game.Enmy.push(a1);
}
if(game.gametime==1060){
    var d1=new enmy_f4();
     var d2=new enmy_f4();
     d1.init(3);
     d2.init(7);
     game.Enmy.push(d1);
     game.Enmy.push(d2);
}
if(game.gametime==1100){
    var e1=new enmy_f5();
    e1.init(3);
    game.Enmy.push(e1);
}
if(game.gametime==1150){
    var e1=new enmy_f5();
    e1.init(5);
    game.Enmy.push(e1);
}
if(game.gametime==1200){
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(0);
    a2.init(7);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    var c1=new enmy_f3();
    c1.init(3.5,5);
    game.Enmy.push(c1);
}
if(game.gametime==1250){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    var d3=new enmy_f4();
    d1.init(1);
    d2.init(3);
    d3.init(5);
    game.Enmy.push(d1);
    game.Enmy.push(d2);
    game.Enmy.push(d3);
}
if(game.gametime==1300){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    var d3=new enmy_f4();
    d1.init(1);
    d2.init(3);
    d3.init(5);
    game.Enmy.push(d1);
    game.Enmy.push(d2);
    game.Enmy.push(d3);
}
if(game.gametime==1350){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    var d3=new enmy_f4();
    d1.init(1);
    d2.init(3);
    d3.init(5);
    game.Enmy.push(d1);
    game.Enmy.push(d2);
    game.Enmy.push(d3);
}
if(game.gametime==1400){
    var c1=new enmy_f3();
    c1.init(2,5);
    game.Enmy.push(c1);
}
if(game.gametime==1430){
    var f1=new enmy_f6();
    var f2=new enmy_f6();
    f1.init(0);
    f2.init(5);
    game.Enmy.push(f1);
    game.Enmy.push(f2);
}
if(game.gametime==1440){
    var c1=new enmy_f3();
    c1.init(4,5);
    game.Enmy.push(c1);
}
if(game.gametime==1470){
     var f1=new enmy_f6();
    var f2=new enmy_f6();
    f1.init(2);
    f2.init(7);
    game.Enmy.push(f1);
    game.Enmy.push(f2);
}
if(game.gametime==1520){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(3);
    b2.init(4);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
}
if(game.gametime==1570){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(1,1);
    b2.init(6,1);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
}
if(game.gametime==1620){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(1,1);
    b2.init(6,1);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
    var c1=new enmy_f3();
    c1.init(3.5,3);
    game.Enmy.push(c1);
}
if(game.gametime==1670){
    var b1=new enmy_f2();
    var b2=new enmy_f2();
    b1.init(3);
    b2.init(4);
    game.Enmy.push(b1);
    game.Enmy.push(b2);
}
if(game.gametime==1720){
    var g1=new enmy_f7();
    var g2=new enmy_f7();
    g1.init(3);
    g2.init(5);
    game.Enmy.push(g1);
    game.Enmy.push(g2);
}
if(game.gametime==1770){
var b1=new enmy_f2();
var a1=new enmy_f1();
var a2=new enmy_f1()
b1.init(4);
a1.init(0);
a2.init(7);
game.Enmy.push(b1);
game.Enmy.push(a1);
game.Enmy.push(a2);
}
if(game.gametime==1820){
    var g1=new enmy_f7();
    var g2=new enmy_f7();
    g1.init(3);
    g2.init(5);
    game.Enmy.push(g1);
    game.Enmy.push(g2);
}
if(game.gametime==1870){
var b1=new enmy_f2();
var a1=new enmy_f1();
var a2=new enmy_f1()
b1.init(4);
a1.init(0);
a2.init(7);
game.Enmy.push(b1);
game.Enmy.push(a1);
game.Enmy.push(a2);
}
if(game.gametime==1920){
    var g1=new enmy_f7();
    var g2=new enmy_f7();
    g1.init(3);
    g2.init(5);
    game.Enmy.push(g1);
    game.Enmy.push(g2);
}
if(game.gametime==1970){
var b1=new enmy_f2();
var a1=new enmy_f1();
var a2=new enmy_f1();
b1.init(4);
a1.init(0);
a2.init(7);
game.Enmy.push(b1);
game.Enmy.push(a1);
game.Enmy.push(a2);
}
if(game.gametime==2020){
    var d1=new enmy_f4();
    d1.init(2);
    game.Enmy.push(d1);
    
}
if(game.gametime==2050){
    var f1=new enmy_f6();
    var f2=new enmy_f6();
    f1.init(0);
    f2.init(4);
    game.Enmy.push(f1);
    game.Enmy.push(f2);
}
if(game.gametime==2100){
    var d1=new enmy_f4();
    d1.init(4);
    game.Enmy.push(d1);
}
if(game.gametime==2130){
    var f1=new enmy_f6();
    var f2=new enmy_f6();
    f1.init(2);
    f2.init(6);
    game.Enmy.push(f1);
    game.Enmy.push(f2);
}
if(game.gametime==2180){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    var d3=new enmy_f4();
    d1.init(0);
    d2.init(2);
    d3.init(4);
    game.Enmy.push(d1);
    game.Enmy.push(d2);
    game.Enmy.push(d3);
}
if(game.gametime==2230){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    var d3=new enmy_f4();
    d1.init(1);
    d2.init(3);
    d3.init(5);
    game.Enmy.push(d1);
    game.Enmy.push(d2);
    game.Enmy.push(d3);
}
if(game.gametime==2280){
    var d1=new enmy_f4();
    var d2=new enmy_f4();
    var d3=new enmy_f4();
    d1.init(0);
    d2.init(2);
    d3.init(4);
    game.Enmy.push(d1);
    game.Enmy.push(d2);
    game.Enmy.push(d3);
}
if(game.gametime==2320){
    var e1=new enmy_f5();
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(1);
    a2.init(6);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
    e1.init(3);
    game.Enmy.push(e1);
}
if(game.gametime==2370){
    var e1=new enmy_f5();
    e1.init(5);
    game.Enmy.push(e1);
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(2);
    a2.init(5);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
}
if(game.gametime==2430){
    var e1=new enmy_f5();
    e1.init(7);
    game.Enmy.push(e1);
    var a1=new enmy_f1();
    var a2=new enmy_f1();
    a1.init(3);
    a2.init(4);
    game.Enmy.push(a1);
    game.Enmy.push(a2);
}
if(game.gametime==2600){
    var boss2=new boss3();
    boss2.init(2);
    game.Enmy.push(boss2);
}
}